<?php

return array(
    'classes' => array (
        'SeoApi' => array(
            'getTopParts' => true,
            'getTopMakes' => true,
            'getTopMakeModels' => true,
            'getTopMakeParts' => true,
        ),
        'CatalogApi' => array (
            'getYearsDecade' => true,
            //'getMakes' => true,
            //'getModels' => true,
        )
    ),
    'cache-enabled' => true,
);
