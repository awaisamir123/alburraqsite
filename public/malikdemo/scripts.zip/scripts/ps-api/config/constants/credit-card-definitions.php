<?php

if (!defined('PAYMENT_PROVIDER_STRIPE_V2')) {
    define('PAYMENT_PROVIDER_STRIPE_V2', 'stripe-v2');
}
if (!defined('PAYMENT_PROVIDER_AUTHORIZE_NET_SIM_V1')) {
    define('PAYMENT_PROVIDER_AUTHORIZE_NET_SIM_V1', 'authorize-net-cim-v1');
}